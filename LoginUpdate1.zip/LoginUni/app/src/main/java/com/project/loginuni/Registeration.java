package com.project.loginuni;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class Registeration extends AppCompatActivity {
    EditText etEmail,etPass,etName,etConPass,etCard;
    Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeration);

        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPass);
        etName = findViewById(R.id.etName);
        etConPass = findViewById(R.id.etConPass);
        etCard = findViewById(R.id.etCard);

        btnLogin = findViewById(R.id.btnReg);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String name,email,pass,conPass,card;

                name = etName.getText().toString();
                email = etEmail.getText().toString();
                pass = etPass.getText().toString();
                conPass = etConPass.getText().toString();
                card = etCard.getText().toString();

                if (name.equals(""))
                {
                    Toast.makeText( Registeration.this, "Name Required", Toast.LENGTH_SHORT).show();
                }
                else if (pass.equals(""))
                {
                    Toast.makeText(Registeration.this, "Password Required",Toast.LENGTH_SHORT).show();
                }
                else if (email.equals(""))
                {
                    Toast.makeText( Registeration.this, "Email Required", Toast.LENGTH_SHORT).show();
                }
                else if (!conPass.equals(""))
                {
                    Toast.makeText(Registeration.this, "Confirm Password Required",Toast.LENGTH_SHORT).show();
                }
                else if (conPass.equals(pass)){
                    Toast.makeText(Registeration.this, "Password Doesn't Match",Toast.LENGTH_SHORT).show();
                }
                else if (card.equals("")){
                    Toast.makeText(Registeration.this, "Card Required",Toast.LENGTH_SHORT).show();
                }
                else if (card.length() != 16){
                    Toast.makeText(Registeration.this, "Invalid Card",Toast.LENGTH_SHORT).show();
                }
                else{
                    //Autentication
                }

            }
        });
    }
}
